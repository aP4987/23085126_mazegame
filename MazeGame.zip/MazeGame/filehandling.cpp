/*
FILE NAME: filehandling.cpp
MAIN FUNCTION: It saves the Players' name and scores and moves taken later on .txt file.

It handles =>
1.	It saves players name, scores and moves taken .
2.	It uses ofstream to write the file and saves the entire game to the file in players name.
This file is called from main .cpp after the label is completed or game ended.
*/

#include "Game.h"
#include "Grid.h"
#include "filehandling.h"
#include <iostream>
#include <fstream>
using namespace std;

//function to save the game to a file.
void SaveandLoadfile(char grid[rows][columns], const char* name, Player &player){
ofstream fout(name);    //create file with a player name

//inside the file, these are going to be displayed.
if(fout.is_open()){
fout<<"PLAYER: "<<name<<"\n"<<endl;
fout<<"Scoreboard: "<<player.score<<"\n"<<endl;
fout<<"Moves taken: "<<player.moves<<"\n"<<endl;

//display game grid inside the file.
fout<<"GAME GRID: \n";
for(int i=0;i<rows ;i++){   //loop for rows and columns
for(int j=0; j<columns;j++){
fout<<grid[i][j];
}
fout<<"\n";
}
fout.close();   //close the file
cout<<"\nThis game is saved for "<<name<<".\n"<<endl;
}
else{

//if file not found then
    cout<<"ERROR OPENING THE FILE!!!"<<endl;
    }
    return;
}
