/*
FILE NAME: main.cpp
MAIN FUNCTION:This is the main file that handles the entire flow of the mazegame; like asking for the players' name, tracking levels, asking for the directions and updating the game conditions as per the users' request.

It handles =>
1. It has the initialization of 10x10 grid for a nice display of the game.
2. It asks for the users name for the input as the Player name in .txt file later on while saving the file.
3. There are three levels. It asks user to select the level which they want to play.
4. It runs the scores, moves taken and collision handling so well by running the loop.
5. It moves enemies as per the user's actions.
6. It helps enemies and collectibles to show inside the grid where the player must collect the collectibles and add +10 points to their scoreboard.
7. It helps tracking every moves the user attended; saving and displaying the final scores and moves after the level completion or game over.
8. It upgrades every time the user is done collecting collectibles from the basic-easy levels to the difficult ones.

FUNCTIONS USED:
1. initGrid (grid);
2. Gridshow (grid);
3. getDirection();
4. collisionhandling(nextstep , player, grid);
5. Enemyandcollectibles(grid, nEnemy, nCollectibles);
6. SaveandLoadfile(grid, name, player);
7. moveEnemy(grid, nEnemy, level, player);

*/

#include<iostream>

//including the header files
#include "Grid.h"
#include "Game.h"
#include "direction.h"
#include "collision.h"
#include "filehandling.h"
using namespace std;

int main(){
//asking for players' name
char name[25];
cout<<"ENTER YOUR NAME: ";
cin>>name;

//current level enemies and collectibles nubering
int nEnemy=0;
int nCollectibles=0;

 int level=1;   //starting level
 int maxlevel=3;    //total levels inside the game

 char grid[rows][columns];   //grid of rows and columns [10x10]
 Player player;  //creating player object to track scores and moves
 int play=1;    //still playing

 //asking user to choose the level
 cout<<"\n~~~~~LEVELS~~~~~ "<<endl;
 cout<<"\n1. EASY LEVEL"<<endl;
 cout<<"2. MEDIUM LEVEL"<<endl;
 cout<<"3. DIFFICULT LEVEL"<<endl;
 cout<<"\nCHOOSE THE LEVEL: ";
  cin>>level;
cout<<"YOU WANT TO PLAY "<<level<<" LEVEL."<<endl;

//MAIN GAME LOOP
//using while-if case, looping for all levels
while (play ==1 && level<=maxlevel){
if(level==1){
    cout<<"\nYOU ARE AT THE LEVEL 1 -> EASY LEVEL.\n"<<endl;

//setting enemy and collectibles
nEnemy=3;
nCollectibles=5;
}
else if (level==2){
    cout<<"\nYOU ARE AT THE LEVEL 2 -> MEDIUM LEVEL.\n"<<endl;
nEnemy=5;
nCollectibles=8;
}
else if (level==3){
    cout<<"\nYOU ARE AT THE LEVEL 3 -> DIFFICULT LEVEL.\n"<<endl;
nEnemy=7;
nCollectibles=10;
}

initGrid (grid);    //setup for 10x10 board with all the attributes like walls,players,enemies, collectibles.etc.
Enemyandcollectibles(grid, nEnemy, nCollectibles);
play=1;

//initial position of the player in rows and columns
int playerRow =1;
int playerColumn =1;
int levelcollectibles=0;    //collected collectibles counts in the levels

//INNER GAME LOOP
while (play==1){    //loop until exit or hit walls or caught an enemy.
Gridshow (grid);    //display the grid
cout<<"\nScoreboard: "<<player.score<<endl;   //scores obtained
cout<<"Moves taken: "<<player.moves<<endl;  //moves lead
cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";

char direction=getDirection();  //ask for the direction here
int newRow = playerRow; //current player position
int newColumn = playerColumn;

//directions
if (direction == 'U') {
            newRow--;  // Move up, decrease row
        }
        else if (direction == 'D') {
            newRow++;  // Move down, increase row
        }
        else if (direction == 'L') {
            newColumn--;  // Move left,decrease column
        }
        else if (direction == 'R') {
            newColumn++;  // Move right,increase column
        }
        else if (direction == 'E') {    //To exit
           return 0;
        }
        else {
            cout << "INVALID MOVE! TRY AGAIN.\n\n";  // any letters rather than directions or exit
            continue;
        }

char nextstep = grid[newRow][newColumn];    // Get what is in the next step now

int result = collisionhandling(nextstep , player, grid);    // Handle collisions
if(result == 0){ //if result=0, game ends
cout<<"GAMEOVER!!!BETTER LUCK NEXT TIME,WARRIOR!\n";
SaveandLoadfile(grid, name, player);
play= 0;
break;
}
else{
if(nextstep=='*'){
player.score+=10;   //10 points add
levelcollectibles++;    //count collectibles of the level
}

grid[playerRow][playerColumn] = ' ';    //empty old player position
playerRow = newRow;     //update player rows and columns
playerColumn = newColumn;
grid[playerRow][playerColumn] = 'P'; //set new player position on the grid
}

player.moves++; //increase in player moves
moveEnemy(grid, nEnemy, level, player); //move enemy

if(levelcollectibles >= nCollectibles){
    cout<<"\n[YOU HAVE COMPLETED THE LEVEL "<<level<<"]\n";
SaveandLoadfile(grid, name, player);

if(level<maxlevel){
        cout<<"     ~~~~~~~~~~~~~~~~~~~~~";
        cout<<"\n~~~| UPGRADING FROM LEVEL "<<level<<" |~~~\n";
        cout<<"     ~~~~~~~~~~~~~~~~~~~~~\n";
    level++;    //next level
    break;
}
else{
    cout<<"WINNER!!!YOU COMPLETED ALL THE LEVELS.\n";
    play=0;
    break;
}
}
}
}
return 0;   //exit
}
