#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

//base class is Entity
class Entity{

public:
//positions in the grid
int rows;
int columns;
};

//class player inherits from the base class Entity
class Player : public Entity{

public:
//stores the scores and move count
int score;
int moves;

//Constructor: special function inside the class
//to initialize the Player
Player();

//return Player's current rows and columns positions.
int getRow(){
return rows;
}
int getColumn(){
return columns;
}

//functions to increase the Player scores and moves
void increaseinScore(int points);
void increaseMoves();
};

#endif // GAME_H_INCLUDED
