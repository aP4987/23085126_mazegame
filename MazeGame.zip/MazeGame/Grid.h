#ifndef GRID_H_INCLUDED
#define GRID_H_INCLUDED

const int rows = 10;
const int columns = 10;

#include "Game.h"

//initializes the grid with #,P,X and *
void initGrid(char grid[rows][columns]);

//display the grid
void Gridshow(char grid[rows][columns]);

//placing enemy and collectibles randomly
void Enemyandcollectibles(char grid[rows][columns], int nEnemy, int nCollectibles);

//move enemies inside the grid based on the number of enemy based on what level and towards the Player
void moveEnemy(char grid[rows][columns], int nEnemy, int level, Player &player);

#endif // GRID_H_INCLUDED
