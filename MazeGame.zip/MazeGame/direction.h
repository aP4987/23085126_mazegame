#ifndef DIRECTION_H_INCLUDED
#define DIRECTION_H_INCLUDED

//gets the direction from the user U/D/L/R or E to exit
char getDirection();

#endif // DIRECTION_H_INCLUDED
