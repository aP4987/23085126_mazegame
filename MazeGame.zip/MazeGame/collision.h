#ifndef COLLISION_H_INCLUDED
#define COLLISION_H_INCLUDED

#include "Grid.h"
#include "Game.h"

//Handles Player's next step and detect collisions with #,X,* or E.
int collisionhandling(char nextstep, Player &player, char grid[rows][columns]);

//moves all enemy around the maze game.
void moveEnemy(char grid[rows][columns], int nEnemy, int level);

#endif // COLLISION_H_INCLUDED
//return 0 if ends, 1 if continues
