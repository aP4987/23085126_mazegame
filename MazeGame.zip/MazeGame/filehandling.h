#ifndef FILEHANDLING_H_INCLUDED
#define FILEHANDLING_H_INCLUDED

#include "Game.h"   //for Player
#include "Grid.h"   //for rows and columns

//loads and saves the file with the player's input.
void SaveandLoadfile(char grid[rows][columns], const char* name, Player &player);

#endif // FILEHANDLING_H_INCLUDED
