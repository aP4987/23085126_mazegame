/*
FILE NAME: Collision.cpp
MAIN FUNCTION: It handles the collision detection between Player with walls, enemy and exit.
It moves the enemy from the function: moveEnemy(char grid[rows][columns], int nEnemy, int level, Player &player)
It helps to add 10 points when collectibles are collected and game gets end when collide with walls or exit point.

 It is called from main.cpp to check if next move from player is valid or no.
 It is called from the moveEnemy() to handle the enemy interactions.
*/

#include <iostream>
#include "Grid.h"
using namespace std;

void moveEnemy(char grid[rows][columns], int nEnemy, int level, Player &player) {
    int enemyPositions[10][2]; //Declaring 2D array that can store up to 10 enemies and for each store 2 values
    int count = 0;

//Store all the current enemy positions
for (int r = 0; r < rows; r++) {
for (int c = 0; c < columns; c++) {
        if (grid[r][c] == 'X') {
            enemyPositions[count][0] = r;
            enemyPositions[count][1] = c;
            count++;
            }
}
}

//move each enemy randomly
for (int i =0; i<count; i++){
    int r= enemyPositions[i][0];
    int c= enemyPositions[i][1];
    grid[r][c]=' '; //clear the old position

    int newRow=r;
    int newCol=c;
    int direction=rand()%4;

//one direction for each time
if(direction==0 && grid[r-1][c]==' ')
    newRow=r-1;     //up direction
else if(direction==1 && grid[r+1][c]==' ')
    newRow=r+1;     //down direction
else if(direction==2 && grid[r][c-1]==' ')
    newCol=c-1;     //up direction
else if(direction==3 && grid[r][c+1]==' ')
    newCol=c+1;     //up direction


//to check if enemy is moving towards the player
if(grid[newRow][newCol]=='P'){
    cout<<"OOPS! AN ENEMY CAUGHT YOU.\n";
    return;   //end the game
}
 grid[newRow][newCol]='X';  //move enemy to new-new positions
}
}

//for collision between the player with walls, exit and collectibles icons
int collisionhandling(char nextstep, Player &player, char grid[rows][columns]){
if(nextstep == '#'){
cout<<"OUCH! YOU JUST HIT A WALL.\n";
return 0;   //end the game
}

else if (nextstep == 'E'){
cout<<"YOU CHOSE TO EXIT.\n";
return 0;   //end the game
}

else if (nextstep == 'X'){
cout<<"OOPS! AN ENEMY CAUGHT YOU.\n";
return 0;   //end the game
}

else if(nextstep == '*'){   //player collects '*'
player.score +=10;      //increase in score on scoreboard
player.increaseMoves();     //increase in moves taken
cout<<"     +10 POINTS\n";
cout<<"!!!YOUR NEW SCORE ON THE SCOREBOARD IS: "<<player.score<<"!!!\n"<<endl;
}
return 1;   //continue the game
}
