/*
FILE NAME: direction.cpp
MAIN FUNCTION: It says about the direction as per the user's input.
It gives the user choice to choose the direction and move towards them.
The directions like up,down,right and left.
It also gives user a choice to end the game by E = exit.

It is called from main.cpp to detect the player's directional movement.
*/


#include <iostream>
#include <string>
using namespace std;

//function to get direction from the user.
char getDirection() {

    string input;   //variable to store the input.

    cout << "\nENTER THE DIRECTION (U/D/L/R OR E to EXIT): ";   //asking user for the input
    cin >> input;   //getting and read the  input

//as per the users' input directing the directions towards it.
    if (input == "U" || input == "u") {
        cout << "YOU CHOSE TO GO UP.\n" << endl;
        return 'U';     // Return 'U' for up direction
    }
    else if (input == "D" || input == "d") {
        cout << "YOU CHOSE TO GO DOWN.\n" << endl;
        return 'D';     //Return 'D' for down direction
    }
    else if (input == "L" || input == "l") {
        cout << "YOU CHOSE TO GO LEFT.\n" << endl;
        return 'L';     //Return 'L' for left direction
    }
    else if (input == "R" || input == "r") {
        cout << "YOU CHOSE TO GO RIGHT.\n" << endl;
        return 'R';     //Return 'R' for right direction
    }
    else if (input == "E" || input == "e") {
        cout << "YOU CHOSE TO EXIT.\n" << endl;
        return 'E';     //Return 'E' for exit direction
    }
    else {
        cout << "INVALID DIRECTION!" << endl;
        return '0';     //Return '0' for invalid input , cannot enter except U,D,L,R,E
    }
}
