/*
FILE NAME: Grid.cpp
MAIN FUNCTION: To initializes the 10x10 grid build with walls, paths, player and exit.
It places the maze grid with walls and space for paths.
It displays the grid.
It places enemy and collectibles randomly.

It is called from main.cpp for initializing and displaying the grid and collision.cpp to move enemies.

*/

#include <iostream>
#include "Grid.h"
using namespace std;

//function to initialize the 10x10 grid build with walls, paths, player and exit.
void initGrid(char grid[rows][columns]){
for(int i=0; i<rows; i++){      //loop for each rows and columns with '#' = walls
for(int j=0; j<columns; j++){

if( i==0 || i==9 || j==0 || j==9){  //1st row is 0 and last is 9 and similarly column 1st is 0 and last is 9
grid[i][j]='#';    //'#'for walls
}
else{
grid[i][j]=' ';    //' 'for paths
}
}
}
//Initial position of Players(rows=1,columns=1)
grid[1][1]='P';
//Initial position to Exit(rows=8,columns=8)
grid[9][9]='E';
}

//To display the grid
void Gridshow(char grid[rows][columns]){
for(int i=0; i<rows; i++){
for(int j=0; j<columns; j++){
        cout<<grid[i][j] <<" "; //display each grid cell with a space between
        }
        cout<<endl; //after each row , move to the next line
        }
}

//function to randomly place the enemy and collectibles
void Enemyandcollectibles(char grid[rows][columns], int nEnemy, int nCollectibles){

 //loop to clear any exisiting 'X' and '*'.
for(int i=0; i<rows; i++){
for(int j=0; j<columns; j++){
 if (grid[i][j]=='X' || grid[i][j]=='*'){
    grid[i][j]=' ';    //empty the path
 }
 }
 }

 //place enemy randomly using rand
 int EnemyCount=0;
 while (EnemyCount<nEnemy){
    int r=rand()% rows;     //select random row and column
    int c=rand()% columns;

//to ensure that the selected cell is emptied by not placing P or E.
    if(grid[r][c]==' ' && (r!=1 || c!=1) && grid[r][c]!='E'){
       grid[r][c]='X'; //random position for enemy
        EnemyCount++;   //increase the enemy count
    }
 }

 //place collectibles randomly using rand
  int CollectiblesCount=0;
 while (CollectiblesCount<nCollectibles){
    int r=rand()% rows;    //select random row and column
    int c=rand()% columns;

//to ensure that the selected cell is emptied by not placing P or E.
    if(grid[r][c]==' ' && (r!=1 || c!=1) && grid[r][c]!='E'){
        grid[r][c]='*';    //random position for collectibles
        CollectiblesCount++;    //increase the collectibles count
    }
 }
 }
