/*
FILE NAME: Game.cpp
MAIN FUNCTION: It defines the player class and its functionality is tracking the player position scores and moves takens
It handles =>
1.	The constructor to initialize the player state.
2.	Function of increasing scores and the  moves taken are implemented here.
This file is called from main.cpp and file handling.cpp

here Player:: is written because these functions belongs to the Player class.
*/

#include "Game.h"

//This is a constructor that initializes player's initial position, scores and the moves taken.
Player::Player(){

//initial rows and columns with score and moves starting at 0
rows=1;
columns=1;
score=0;
moves=0;
}

//function to increase scores by giving points to the player
void Player::increaseinScore(int points){
score=score + points;
}

//function to increase move count by 1 every time the player enters direction.
void Player::increaseMoves(){
moves++ ;
}
